<script setup lang="ts">
// import Reactive from '@/views/reactive/index.vue'
// import PushBoxOOP from '@/views/pushBoxOOP/index.vue'
import PushBoxFunctional from '@/views/pushBoxFunctional/index.vue'
</script>

<template>
	<!-- <Reactive /> -->
	<!-- <PushBoxOOP /> -->
	<PushBoxFunctional />
</template>

<style scoped>
.logo {
	height: 6em;
	padding: 1.5em;
	will-change: filter;
	transition: filter 300ms;
}

.logo:hover {
	filter: drop-shadow(0 0 2em #646cffaa);
}

.logo.vue:hover {
	filter: drop-shadow(0 0 2em #42b883aa);
}
</style>
