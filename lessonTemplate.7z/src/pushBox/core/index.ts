import { PushBox as PushBoxOOP } from "./oop"
import { usePushBox } from "./functional"

export { PushBoxOOP, usePushBox }
