// console.log(123);
// import './linearDataStructure'
import "./twoDimensionalDataStructure"
